﻿using System;

namespace application
{
    public class Class1
    {
    }
}

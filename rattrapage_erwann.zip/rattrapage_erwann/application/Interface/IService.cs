﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace application.Interface
{
    public class IService<T>
    {
        Task<int> CreateAsync(T applicationModel);
        Task Delete(Guid guid);
        Task<List<T>> GetListAsync();
        Task<T> GetByIdAsync(Guid guid);
        Task<T> GetByNameAsync(string name);
        Task UpdateAsync(T applicationModel);
    }
}

﻿using application.Models;
using domain.ValueObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace application.Mappers
{
    public class CommuneMapper
    {
        public static CommuneModel ToCommuneModel(Commune commune)
        {
            return new CommuneModel
            {
                NomCommune = commune.NomCommune,
                Superficie = commune.Superficie
            };
        }

        public static Commune ToData(Commune communeModel)
        {
            return new Commune
            {
                NomCommune = communeModel.NomCommune,
                Superficie = communeModel.Superficie
            };
        }
    }
}

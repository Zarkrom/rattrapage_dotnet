﻿using application.Models;
using domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace application.Mappers
{
    public class DepartementMapper
    {
        public static DepartementModel ToDepartementModel(Departement departement)
        {
            return new DepartementModel
            {
                NomDepartement = departement.NomDepartement,
                Superficie = departement.Superficie,
                Communes = departement.Communes.Select(CommuneMapper.ToCommuneModel).ToList()
            };
        }

        public static Departement ToData(Departement departementModel)
        {
            return new Departement
            {
                NomDepartement = departementModel.NomDepartement,
                Superficie = departementModel.Superficie,
                Communes = departementModel.Communes.Select(CommuneMapper.ToCommuneModel).ToList()
            };
        }
    }
}

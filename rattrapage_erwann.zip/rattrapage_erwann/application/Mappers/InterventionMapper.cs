﻿using application.Models;
using domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace application.Mappers
{
    public class InterventionMapper
    {
        public static InterventionModel ToInterventionModel(Intervention intervention)
        {
            return new InterventionModel
            {
                
            };
        }

        public static Intervention ToData(Intervention interventionModel)
        {
            return new Intervention
            {
                
            };
        }

    }
}

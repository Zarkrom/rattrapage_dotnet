﻿using application.Models;
using domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace application.Mappers
{
    public class PersonneMapper
    {
        public static PersonneModel ToPersonneModel(Personne personne)
        {
            return new PersonneModel
            {

            };
        }

        public static Personne ToData(Personne personneModel)
        {
            return new Personne
            {

            };
        }
    }
}

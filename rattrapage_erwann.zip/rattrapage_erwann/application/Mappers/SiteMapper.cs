﻿using application.Models;
using domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace application.Mappers
{
    public class SiteMapper
    {
        public static SiteModel ToSiteModel(Site site)
        {
            return new SiteModel
            {

            };
        }

        public static Site ToData(Site siteModel)
        {
            return new Site
            {

            };
        }
    }
}

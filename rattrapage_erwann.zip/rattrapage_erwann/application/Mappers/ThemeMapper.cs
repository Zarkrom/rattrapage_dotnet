﻿using application.Models;
using domain.ValueObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace application.Mappers
{
    public class ThemeMapper
    {
        public static ThemeModel ToThemeModel(Theme theme)
        {
            return new ThemeModel
            {

            };
        }

        public static Theme ToData(Theme themeModel)
        {
            return new Theme
            {

            };
        }
    }
}

﻿namespace application.Mappers
{
    public class TypeInter
    {
    }
}
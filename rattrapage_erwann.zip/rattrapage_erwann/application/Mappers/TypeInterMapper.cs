﻿using application.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace application.Mappers
{
    public class TypeInterMapper
    {
        public static TypeInterModel ToTypeInterModel(TypeInter typeInter)
        {
            return new TypeInterModel
            {

            };
        }

        public static TypeInter ToData(TypeInter typeInterModel)
        {
            return new TypeInter
            {

            };
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace application.Models
{
    public class CommuneModel
    {
        public virtual DepartementModel Departement { get; set; }

        public string NomCommune { get; set; }
        public float Superficie { get; set; }
    }
}

﻿using domain.ValueObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace application.Models
{
    public class DepartementModel
    {
        public string NomDepartement { get; set; }
        public float Superficie { get; set; }

        private readonly List<Commune> _communes = new List<Commune>();
    }
}

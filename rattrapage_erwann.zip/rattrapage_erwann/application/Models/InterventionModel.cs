﻿using domain.Entities;
using domain.ValueObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace application.Models
{
    public class InterventionModel
    {
        public Site Site { get; set; }
        public DateTime DateDebut { get; set; }
        public DateTime DateFin { get; set; }
        public typeInter TypeInter { get; set; }
        private readonly List<Theme> _themes = new List<Theme>();
        private readonly List<Personne> _personnes = new List<Personne>();
    }
}

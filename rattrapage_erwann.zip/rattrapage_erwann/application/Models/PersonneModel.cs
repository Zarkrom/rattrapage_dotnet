﻿using domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace application.Models
{
    public class PersonneModel
    {
        private readonly List<Intervention> _interventions = new List<Intervention>();
        public string Role { get; set; }
        public string Nom { get; set; }
        public string Prenom { get; set; }
    }
}

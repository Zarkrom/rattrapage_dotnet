﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace application.Repositories
{
    public interface IRepository<T>
    {
        Task<List<T>> GetListAsync();
        Task<T> GetByIdAsync(Guid entityId);
        Task<T> GetByNameAsync(string name);
        Task<int> InsertAsync(T entity);
        Task UpdateAsync(T entity);
        Task DeleteAsync(Guid entity);
    }
}

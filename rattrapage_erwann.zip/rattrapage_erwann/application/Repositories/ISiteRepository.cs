﻿using application.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace application.Repositories
{
    public interface ISiteRepository : IRepository<SiteModel>
    {
    }
}

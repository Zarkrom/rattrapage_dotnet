﻿using System;

namespace domain
{
    public class Class1
    {
    }
}

﻿using domain.Commons;
using domain.ValueObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace domain.Entities
{
    public class Intervention : Entity
    {
        public Site Site { get; set; }

        public DateTime DateDebut { get; set; }
        public DateTime DateFin { get; set; }

        public typeInter TypeInter { get; set; }

        private readonly List<Theme> _themes = new List<Theme>();

        // liste thème (valueobject)
    }
}

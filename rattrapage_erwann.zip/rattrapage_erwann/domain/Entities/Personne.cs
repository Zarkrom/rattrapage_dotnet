﻿using domain.Commons;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace domain.Entities
{
    public class Personne : Entity
    {
        private readonly List<Intervention> _interventions = new List<Intervention>();

        public string Role { get; set; }
        public string Nom { get; set; }
        public string Prenom { get; set; }

    }
}

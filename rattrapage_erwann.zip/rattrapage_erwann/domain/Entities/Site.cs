﻿using domain.Commons;
using domain.ValueObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace domain.Entities
{
    public class Site : Entity
    {
        private readonly List<Commune> _communes = new List<Commune>();
        //liste thèmes (valueobjects)

        private readonly List<Theme> _themes = new List<Theme>();


    }
}

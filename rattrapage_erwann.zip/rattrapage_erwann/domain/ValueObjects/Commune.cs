﻿using domain.Commons;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace domain.ValueObjects
{
    public class Commune : Entity
    {
        public string NomCommune { get; set; }
        public float Superficie { get; set; }



    }
}

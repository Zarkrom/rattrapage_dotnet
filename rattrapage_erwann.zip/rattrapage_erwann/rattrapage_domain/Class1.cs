﻿using System;

namespace rattrapage_domain
{
    public class Class1
    {
    }
}

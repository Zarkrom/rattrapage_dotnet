﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace rattrapage_domain.ValueObjects
{
    public class Intervention
    {
        public int interventionID { get; set; }
        public string typeIntervention { get; set; }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace rattrapage_domain.ValueObjects
{
    public class Theme
    {
        public int themeID { get; set; }

        public string nameTheme { get; set; }
    }
}
